"""
Web 医院管理系统项目的 WSGI 配置。
它将 WSGI 可调用公开为名为“application”的模块级变量。
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'webhopital.settings')

application = get_wsgi_application()
