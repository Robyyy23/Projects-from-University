"""
网络医院管理系统项目的ASGI配置。
它将 ASGI 可调用对象公开为名为“application”的模块级变量。
"""

import os

from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'webhospital.settings')

application = get_asgi_application()
