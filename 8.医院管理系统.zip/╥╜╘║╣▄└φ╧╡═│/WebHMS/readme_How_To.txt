

Hospital Management System [[ Web HMS]]  (Python_Django)

## INSTRUCTION TO RUN THIS PROJECT
- Install Python(3.10.0) (Dont Forget to Tick Add to Path while installing Python)
- Install Django 3.1.0
- Open Terminal and Execute Following Commands/Paste the following commad in terminal:
 
```

1) Install the Requirements: 
      pip install -r requirements.txt
       
   or: 
    -pip install django==3.2.8
    -pip install django-widget-tweaks
    -pip install xhtml2pdf

2) Then, make database migrations: 
     python manage.py makemigrations

     python manage.py migrate

3) And finally, run the application: 
    python manage.py runserver

Paste the following commad in terminal:

python manage.py makemigrations
python manage.py migrate
python manage.py runserver



For Admin Account, can create one with superuser! #notcreated*



- In the VSC Terminal. Then run following Commands :
```
py manage.py makemigrations
py manage.py migrate
py manage.py runserver

```
- Now enter following URL in Your Browser Installed On Your PC

  Starting development server at http://127.0.0.1:8000/   or    Ctrl-Click the link in terminal
```
  Quit the server with CTRL-BREAK.
```
